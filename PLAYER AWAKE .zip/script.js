
"use strict";

/* ==========================================
   PLAYER AWAKE - COMPLETE MINI GAME ENGINE
   ========================================== */

const $ = (id) => document.getElementById(id);

const GAME_INFO = {
  reflex: {
    title: "Reflex Rush",
    icon: "⚡",
    mode: "REACTION",
    description: "Your reaction time decides your score. Stay sharp!",
    instructions: "Tap the glowing target as quickly as possible. Hit as many targets as you can before time runs out.",
    tip: "Fast reactions earn more points."
  },
  memory: {
    title: "Memory Matrix",
    icon: "🧠",
    mode: "MEMORY",
    description: "Remember the pattern. Every round gets harder.",
    instructions: "Watch the tiles light up, then repeat their sequence in the same order. One mistake ends your run.",
    tip: "Focus on the sequence, not the speed."
  },
  runner: {
    title: "Neon Runner",
    icon: "🏃",
    mode: "ENDLESS RUN",
    description: "One runner. Three lanes. Avoid every obstacle.",
    instructions: "Move between lanes using the arrow buttons or keyboard. Dodge obstacles and survive as long as possible.",
    tip: "Look ahead and plan your next move."
  },
  nexus: {
    title: "Number Nexus",
    icon: "🔢",
    mode: "PUZZLE",
    description: "Combine matching numbers and chase your best score.",
    instructions: "Use the arrow keys or swipe to slide tiles. Matching numbers merge. Reach bigger numbers without filling the board.",
    tip: "Keep an empty lane for your next move."
  },
  duel: {
    title: "Mind Duel",
    icon: "♟️",
    mode: "STRATEGY",
    description: "Can you outsmart the arena's AI?",
    instructions: "Place X in a square. Get three in a row before the AI gets three O's. Draws count as a completed match.",
    tip: "Control the center whenever you can."
  },
  survival: {
    title: "Survival Protocol",
    icon: "🚀",
    mode: "SURVIVAL",
    description: "Dodge incoming hazards and survive the arena.",
    instructions: "Move your ship left and right to avoid falling hazards. Survive the timer to earn a bonus.",
    tip: "Keep moving, but watch where you're heading."
  },
  daily: {
    title: "Daily Quest",
    icon: "🏆",
    mode: "SPECIAL MISSION",
    description: "A focused challenge with a bonus reward.",
    instructions: "Collect the glowing quest orbs before time runs out. Complete the mission to earn bonus XP.",
    tip: "Each successful orb brings you closer to your goal."
  }
};

const DIFFICULTY = {
  easy:   { label: "EASY", time: 35, targetSize: 68, spawn: 1050 },
  medium: { label: "MEDIUM", time: 25, targetSize: 54, spawn: 800 },
  hard:   { label: "HARD", time: 18, targetSize: 42, spawn: 600 }
};

const DEFAULT_PROFILE = {
  xp: 0,
  played: 0,
  best: {},
  achievements: [],
  totalScore: 0
};

let profile = loadProfile();
let currentGame = "reflex";
let difficulty = "easy";
let score = 0;
let seconds = 0;
let running = false;
let paused = false;
let ended = false;
let round = 0;
let playerLane = 1;
let playerColumn = 1;
let playerRow = 1;
let hazards = [];
let board = [];
let memorySequence = [];
let memoryInput = [];
let questCount = 0;
let questGoal = 8;
let duelBoard = Array(9).fill("");
let gameTimers = [];
let tickCount = 0;
let gameStartedAt = 0;
let previousFrame = 0;
let lastSpawn = 0;
let swipeStart = null;
let lastDirection = "";
let bestAtStart = 0;

/* ---------- PROFILE & STORAGE ---------- */

function loadProfile() {
  try {
    const saved = JSON.parse(localStorage.getItem("playerAwakeProfile"));
    if (saved && typeof saved === "object") {
      return {
        ...DEFAULT_PROFILE,
        ...saved,
        best: saved.best || {},
        achievements: saved.achievements || []
      };
    }
  } catch (error) {
    console.warn("Could not load saved profile.");
  }
  return { ...DEFAULT_PROFILE, best: {}, achievements: [] };
}

function saveProfile() {
  try {
    localStorage.setItem("playerAwakeProfile", JSON.stringify(profile));
  } catch (error) {
    console.warn("Progress could not be saved on this browser.");
  }
}

function bestScore(id) {
  return Number(profile.best[id]) || 0;
}

function getLevel() {
  return Math.floor(profile.xp / 100) + 1;
}

function updateProfileUI() {
  $("headerXP").textContent = profile.xp;
  $("headerLevel").textContent = getLevel();
  $("progressLevel").textContent = getLevel();
  $("xpProgressText").textContent =
    `${profile.xp % 100} / 100 XP`;
  $("xpProgress").style.width = `${profile.xp % 100}%`;
  $("homePlayed").textContent = profile.played;

  $("homeBest").textContent = Math.max(
    0, ...Object.values(profile.best).map(Number)
  );

  renderAchievements();
}

function renderAchievements() {
  const achievements = [
    { id: "first", icon: "🎮", title: "First Steps", desc: "Finish your first game." },
    { id: "five", icon: "🔥", title: "Getting Warm", desc: "Finish 5 games." },
    { id: "score", icon: "💎", title: "Score Hunter", desc: "Earn 100 points in a game." },
    { id: "level", icon: "⭐", title: "Level Up", desc: "Reach level 2." },
    { id: "all", icon: "🌌", title: "Explorer", desc: "Play all 7 game modes." }
  ];

  const playedModes = Object.keys(profile.best);
  $("achievements").innerHTML = achievements.map(a => {
    const unlocked =
      (a.id === "first" && profile.played >= 1) ||
      (a.id === "five" && profile.played >= 5) ||
      (a.id === "score" && Math.max(0, ...Object.values(profile.best)) >= 100) ||
      (a.id === "level" && getLevel() >= 2) ||
      (a.id === "all" && playedModes.length >= 7);

    return `
      <div class="achievement ${unlocked ? "unlocked" : ""}">
        <span class="achievement-icon">${a.icon}</span>
        <div><strong>${a.title}</strong><small>${unlocked ? "Unlocked!" : a.desc}</small></div>
      </div>`;
  }).join("");
}

/* ---------- NAVIGATION ---------- */

function showScreen(id) {
  document.querySelectorAll(".screen").forEach(s => {
    s.classList.toggle("active", s.id === id);
  });
  window.scrollTo({ top: 0, behavior: "smooth" });
}

function scrollToGames() {
  $("gamesSection").scrollIntoView({ behavior: "smooth", block: "start" });
}

function openGame(id) {
  if (!GAME_INFO[id]) return;
  cleanupGame();
  currentGame = id;
  difficulty = "easy";
  updateProfileUI();

  const info = GAME_INFO[id];
  $("introIcon").textContent = info.icon;
  $("introTitle").textContent = info.title;
  $("introDescription").textContent = info.description;
  $("introMode").textContent = info.mode;
  $("introBest").textContent = bestScore(id);
  $("introInstructions").textContent = info.instructions;

  document.querySelectorAll(".difficulty").forEach(button => {
    button.classList.toggle(
      "selected", button.dataset.difficulty === difficulty
    );
  });

  showScreen("introScreen");
}

function selectDifficulty(value) {
  if (!DIFFICULTY[value]) return;
  difficulty = value;

  document.querySelectorAll(".difficulty").forEach(button => {
    button.classList.toggle(
      "selected", button.dataset.difficulty === value
    );
  });
}

function goHome() {
  cleanupGame();
  $("modal").classList.add("hidden");
  showScreen("homeScreen");
  updateProfileUI();
}

function cleanupGame() {
  running = false;
  paused = false;
  ended = true;

  gameTimers.forEach(id => {
    clearInterval(id);
    clearTimeout(id);
  });
  gameTimers = [];

  $("pauseBtn").textContent = "Ⅱ";
  $("modal").classList.add("hidden");
}

function addTimer(callback, delay, repeat = false) {
  const id = repeat
    ? setInterval(callback, delay)
    : setTimeout(callback, delay);
  gameTimers.push(id);
  return id;
}

/* ---------- COMMON GAME START ---------- */

function startGame() {
  cleanupGame();

  score = 0;
  seconds = DIFFICULTY[difficulty].time;
  round = 0;
  tickCount = 0;
  hazards = [];
  questCount = 0;
  questGoal = difficulty === "hard" ? 12 : difficulty === "medium" ? 10 : 8;
  duelBoard = Array(9).fill("");
  memorySequence = [];
  memoryInput = [];
  board = [];
  playerLane = 1;
  playerColumn = 1;
  playerRow = 1;
  ended = false;
  paused = false;
  running = true;
  gameStartedAt = Date.now();
  previousFrame = 0;
  lastSpawn = 0;
  bestAtStart = bestScore(currentGame);

  const info = GAME_INFO[currentGame];
  $("playIcon").textContent = info.icon;
  $("playTitle").textContent = info.title;
  $("bestDisplay").textContent = bestAtStart;
  $("gameTip").textContent = info.tip;
  $("pauseBtn").textContent = "Ⅱ";
  $("gameControls").innerHTML = "";
  $("gameArea").innerHTML = "";
  $("gameMessage").textContent = "GO!";

  $("stat2Label").textContent =
    currentGame === "memory" ? "ROUND" :
    currentGame === "duel" ? "MATCH" : "TIME";

  $("stat2Value").textContent =
    currentGame === "memory" || currentGame === "duel" ? "1" : seconds;

  showScreen("playScreen");
  updateScore();

  switch (currentGame) {
    case "reflex": initReflex(); break;
    case "memory": initMemory(); break;
    case "runner": initRunner(); break;
    case "nexus": initNexus(); break;
    case "duel": initDuel(); break;
    case "survival": initSurvival(); break;
    case "daily": initDaily(); break;
  }
}

function updateScore() {
  $("scoreDisplay").textContent = score;
}

function addScore(amount) {
  score = Math.max(0, score + amount);
  updateScore();
}

function updateStat(value) {
  $("stat2Value").textContent = value;
}

function setMessage(message) {
  $("gameMessage").textContent = message;
}

/* ---------- GAME END & REWARDS ---------- */

function finishGame(won = false, reason = "") {
  if (ended) return;

  ended = true;
  running = false;

  gameTimers.forEach(id => {
    clearInterval(id);
    clearTimeout(id);
  });
  gameTimers = [];

  const id = currentGame;
  const oldBest = bestScore(id);
  const newRecord = score > oldBest;

  profile.best[id] = Math.max(oldBest, score);
  profile.played += 1;
  profile.totalScore += score;

  // XP is earned for participation and performance.
  const xpEarned = Math.max(5, Math.floor(score / 5)) +
    (won ? 10 : 0) + (newRecord && score > 0 ? 5 : 0);

  profile.xp += xpEarned;

  if (!profile.achievements.includes("first")) {
    profile.achievements.push("first");
  }

  saveProfile();
  updateProfileUI();

  $("modalIcon").textContent = won ? "🏆" : "⚡";
  $("modalEyebrow").textContent = won ? "MISSION COMPLETE" : "RUN COMPLETE";
  $("modalTitle").textContent = won ? "Challenge cleared!" : "Keep improving!";
  $("modalText").textContent = reason || (
    won ? "Excellent work. You completed the challenge." :
    "Every run is a chance to beat your personal best."
  );

  $("modalStats").innerHTML = `
    <div class="modal-stat"><span>FINAL SCORE</span><b>${score}</b></div>
    <div class="modal-stat"><span>XP EARNED</span><b>+${xpEarned}</b></div>
    <div class="modal-stat"><span>PERSONAL BEST</span><b>${profile.best[id]}</b></div>
    <div class="modal-stat"><span>DIFFICULTY</span><b>${DIFFICULTY[difficulty].label}</b></div>`;

  $("modalMainBtn").textContent = "PLAY AGAIN ↻";
  $("modal").classList.remove("hidden");
}

function modalMainAction() {
  if (paused && !ended) {
    $("modal").classList.add("hidden");
    paused = false;
    running = true;
    $("pauseBtn").textContent = "Ⅱ";
    if (currentGame === "runner" || currentGame === "survival") {
      previousFrame = Date.now();
    }
    return;
  }

  $("modal").classList.add("hidden");
  startGame();
}

function togglePause() {
  if (ended) return;

  if (paused) {
    paused = false;
    running = true;
    $("pauseBtn").textContent = "Ⅱ";
    $("modal").classList.add("hidden");
    previousFrame = Date.now();
    setMessage("KEEP GOING!");
  } else {
    paused = true;
    running = false;
    $("pauseBtn").textContent = "▶";
    $("modalIcon").textContent = "Ⅱ";
    $("modalEyebrow").textContent = "GAME PAUSED";
    $("modalTitle").textContent = "Take a breath.";
    $("modalText").textContent = "Your progress is waiting for you.";
    $("modalStats").innerHTML = `
      <div class="modal-stat"><span>CURRENT SCORE</span><b>${score}</b></div>
      <div class="modal-stat"><span>TIME LEFT</span><b>${seconds}</b></div>`;
    $("modalMainBtn").textContent = "RESUME ▶";
    $("modal").classList.remove("hidden");
  }
}

/* ---------- 1. REFLEX RUSH ---------- */

function initReflex() {
  const area = $("gameArea");
  let target = null;
  let hitCount = 0;

  function spawnTarget() {
    if (!running || ended) return;
    if (target) target.remove();

    target = document.createElement("button");
    target.className = "target";
    target.textContent = "✦";
    target.setAttribute("aria-label", "Tap target");
    const size = DIFFICULTY[difficulty].targetSize;

    const maxX = Math.max(0, area.clientWidth - size - 12);
    const maxY = Math.max(0, area.clientHeight - size - 12);

    target.style.width = size + "px";
    target.style.height = size + "px";
    target.style.left = (6 + Math.random() * maxX) + "px";
    target.style.top = (6 + Math.random() * maxY) + "px";

    target.onclick = () => {
      if (!running || ended) return;
      hitCount++;
      addScore(10);
      setMessage("NICE HIT! +" + 10);
      spawnTarget();
    };

    area.appendChild(target);
  }

  spawnTarget();

  addTimer(() => {
    if (!running || ended) return;
    seconds--;
    updateStat(seconds);

    if (seconds <= 0) {
      finishGame(hitCount > 0, "You hit " + hitCount + " targets. Try to beat your record!");
    }
  }, 1000, true);
}

/* ---------- 2. MEMORY MATRIX ---------- */

function initMemory() {
  const area = $("gameArea");
  const grid = document.createElement("div");
  grid.className = "matrix-grid";

  const tiles = [];
  for (let i = 0; i < 9; i++) {
    const button = document.createElement("button");
    button.className = "matrix-tile";
    button.textContent = "•";
    button.setAttribute("aria-label", "Memory tile " + (i + 1));
    button.disabled = true;
    grid.appendChild(button);
    tiles.push(button);
  }

  area.appendChild(grid);

  const lengthForRound = () => Math.min(
    2 + round, difficulty === "easy" ? 7 :
      difficulty === "medium" ? 9 : 12
  );

  function showRound() {
    if (!running || ended) return;

    round++;
    memorySequence = [];
    memoryInput = [];
    updateStat(round);
    setMessage("MEMORIZE THE PATTERN!");

    const length = lengthForRound();
    for (let i = 0; i < length; i++) {
      memorySequence.push(Math.floor(Math.random() * 9));
    }

    tiles.forEach(tile => {
      tile.classList.remove("lit");
      tile.textContent = "•";
      tile.disabled = true;
    });

    let index = 0;
    const speed = difficulty === "hard" ? 330 :
      difficulty === "medium" ? 470 : 620;

    const showNext = () => {
      if (!running || ended) return;

      tiles.forEach(tile => tile.classList.remove("lit"));

      if (index >= memorySequence.length) {
        setMessage("YOUR TURN — REPEAT IT!");
        tiles.forEach(tile => tile.disabled = false);
        return;
      }

      const tile = tiles[memorySequence[index]];
      tile.classList.add("lit");
      tile.textContent = "✦";
      index++;

      addTimer(() => {
        tile.classList.remove("lit");
        tile.textContent = "•";
        addTimer(showNext, 170);
      }, speed);
    };

    addTimer(showNext, 450);
  }

  tiles.forEach((tile, index) => {
    tile.onclick = () => {
      if (!running || ended || paused) return;

      tile.classList.add("lit");
      addTimer(() => tile.classList.remove("lit"), 140);

      const expected = memorySequence[memoryInput.length];

      if (index !== expected) {
        setMessage("PATTERN BROKEN!");
        finishGame(false, "You reached round " + round + ". Train your memory and try again.");
        return;
      }

      memoryInput.push(index);

      if (memoryInput.length === memorySequence.length) {
        addScore(round * 15);
        setMessage("PERFECT! NEXT ROUND...");
        tiles.forEach(t => t.disabled = true);
        addTimer(showRound, 650);
      }
    };
  });

  addTimer(showRound, 350);
}

/* ---------- 3. NEON RUNNER ---------- */

function initRunner() {
  const area = $("gameArea");
  area.innerHTML = `
    <div class="runner-world">
      <div class="runner-lanes"><div></div><div></div><div></div></div>
      <div id="runnerPlayer" class="runner-player">🏃</div>
    </div>`;

  const player = $("runnerPlayer");
  const controls = $("gameControls");

  controls.innerHTML = `
    <button class="runner-btn" id="leftLane" aria-label="Move left">◀</button>
    <button class="runner-btn" id="rightLane" aria-label="Move right">▶</button>`;

  function positionPlayer() {
    const laneWidth = area.clientWidth * .8 / 3;
    const leftStart = area.clientWidth * .1;
    player.style.left = (
      leftStart + playerLane * laneWidth + laneWidth / 2 - 23
    ) + "px";
  }

  function moveLane(dir) {
    if (!running || ended) return;
    playerLane = Math.max(0, Math.min(2, playerLane + dir));
    positionPlayer();
  }

  $("leftLane").onclick = () => moveLane(-1);
  $("rightLane").onclick = () => moveLane(1);
  positionPlayer();

  const world = area.querySelector(".runner-world");
  let frame = 0;
  const spawnEvery = difficulty === "hard" ? 7 :
    difficulty === "medium" ? 10 : 13;

  function frameRunner() {
    if (!running || ended) return;

    frame++;
    if (frame % spawnEvery === 0) {
      const obstacle = document.createElement("div");
      obstacle.className = "runner-obstacle";
      obstacle.textContent = "✖";
      const lane = Math.floor(Math.random() * 3);
      obstacle.dataset.lane = lane;
      obstacle.dataset.y = "-48";
      world.appendChild(obstacle);
      hazards.push(obstacle);
    }

    hazards = hazards.filter(obstacle => {
      if (!obstacle.isConnected) return false;

      let y = Number(obstacle.dataset.y || -48);
      y += difficulty === "hard" ? 8 : difficulty === "medium" ? 6 : 4;
      obstacle.dataset.y = y;
      obstacle.style.top = y + "px";

      const lane = Number(obstacle.dataset.lane);
      const laneWidth = area.clientWidth * .8 / 3;
      const leftStart = area.clientWidth * .1;
      obstacle.style.left = (
        leftStart + lane * laneWidth + laneWidth / 2 - 23
      ) + "px";

      if (y > area.clientHeight - 80 && y < area.clientHeight - 5 &&
          lane === playerLane) {
        finishGame(false, "You survived " + seconds + " seconds. Try another run!");
      }

      if (y > area.clientHeight) {
        obstacle.remove();
        addScore(2);
        return false;
      }
      return true;
    });

    if (frame % 10 === 0) addScore(1);
  }

  addTimer(frameRunner, 70, true);
  addTimer(() => {
    if (!running || ended) return;
    seconds--;
    updateStat(seconds);

    if (seconds <= 0) {
      addScore(50);
      finishGame(true, "You survived the full run! Bonus points awarded.");
    }
  }, 1000, true);
}

/* ---------- 4. NUMBER NEXUS ---------- */

function initNexus() {
  const area = $("gameArea");
  area.innerHTML = '<div class="number-grid" id="numberGrid"></div>';

  board = Array(16).fill(0);
  addRandomTile();
  addRandomTile();
  renderNexus();

  $("gameTip").textContent =
    "Swipe or use arrow keys. Matching tiles combine.";

area.ontouchstart = onSwipeStart;
area.ontouchend = onSwipeEnd;

  function move(direction) {
    if (!running || ended || paused) return;

    const before = board.join(",");
    let gained = 0;

    function mergeLine(indices) {
      const values = indices.map(i => board[i]).filter(v => v > 0);
      const merged = [];

      for (let i = 0; i < values.length; i++) {
        if (values[i] === values[i + 1]) {
          merged.push(values[i] * 2);
          gained += values[i] * 2;
          i++;
        } else {
          merged.push(values[i]);
        }
      }

      while (merged.length < 4) merged.push(0);
      indices.forEach((index, i) => board[index] = merged[i]);
    }

    for (let line = 0; line < 4; line++) {
      let indices = [];

      for (let pos = 0; pos < 4; pos++) {
        if (direction === "left") indices.push(line * 4 + pos);
        if (direction === "right") indices.push(line * 4 + (3 - pos));
        if (direction === "up") indices.push(pos * 4 + line);
        if (direction === "down") indices.push((3 - pos) * 4 + line);
      }

      mergeLine(indices);
    }

    if (before === board.join(",")) return;

    addScore(gained);
    addRandomTile();
    renderNexus();

    if (!board.includes(0)) {
      finishGame(false, "The board is full. Try a different merging strategy.");
    }
  }

  function onSwipeStart(e) {
    const touch = e.changedTouches[0];
    swipeStart = { x: touch.clientX, y: touch.clientY };
  }

  function onSwipeEnd(e) {
    if (!swipeStart) return;
    const touch = e.changedTouches[0];
    const dx = touch.clientX - swipeStart.x;
    const dy = touch.clientY - swipeStart.y;
    swipeStart = null;

    if (Math.max(Math.abs(dx), Math.abs(dy)) < 25) return;
    move(Math.abs(dx) > Math.abs(dy)
      ? (dx > 0 ? "right" : "left")
      : (dy > 0 ? "down" : "up"));
  }

  // Store the handler for cleanup on the next start.
  nexusKeyMove = move;

  function renderNexus() {
    const grid = $("numberGrid");
    if (!grid) return;

    grid.innerHTML = board.map((value, i) => `
      <button class="number-tile" data-value="${value}"
        aria-label="Tile ${value || 'empty'}"
        onclick="nexusTap(${i})">${value || ""}</button>
    `).join("");
  }
}

let nexusKeyMove = null;

function nexusTap(index) {
  // Tap is intentionally non-destructive; use directional movement.
  if (!running || ended) return;
  setMessage("USE THE ARROW KEYS OR SWIPE TO MERGE");
}

function addRandomTile() {
  const empty = board.map((v, i) => v === 0 ? i : -1).filter(i => i >= 0);
  if (!empty.length) return;
  const index = empty[Math.floor(Math.random() * empty.length)];
  board[index] = Math.random() < 0.9 ? 2 : 4;
}
/* ---------- 5. MIND DUEL ---------- */

function initDuel() {
  const area = $("gameArea");
  area.innerHTML = '<div class="duel-board" id="duelBoard"></div>';
  setMessage("YOUR TURN — YOU ARE X");
  renderDuel();

  function renderDuel() {
    $("duelBoard").innerHTML = duelBoard.map((mark, index) => `
      <button class="duel-cell ${mark === "O" ? "mark-o" : ""}"
        ${mark ? "disabled" : ""}
        aria-label="Square ${index + 1}"
        onclick="duelMove(${index})">${mark}</button>
    `).join("");
  }

  duelRender = renderDuel;
}

let duelRender = () => {};

function checkWinner(b) {
  const lines = [
    [0,1,2],[3,4,5],[6,7,8],
    [0,3,6],[1,4,7],[2,5,8],
    [0,4,8],[2,4,6]
  ];

  for (const [a, b1, c] of lines) {
    if (b[a] && b[a] === b[b1] && b[a] === b[c]) return b[a];
  }

  return b.every(Boolean) ? "DRAW" : null;
}

function duelMove(index) {
  if (!running || ended || paused || duelBoard[index]) return;

  duelBoard[index] = "X";
  duelRender();

  let winner = checkWinner(duelBoard);
  if (winner) {
    endDuel(winner);
    return;
  }

  setMessage("AI IS THINKING...");

  addTimer(() => {
    if (!running || ended) return;

    const move = findBestMove(duelBoard);
    if (move !== -1) duelBoard[move] = "O";

    duelRender();
    winner = checkWinner(duelBoard);

    if (winner) {
      endDuel(winner);
    } else {
      setMessage("YOUR TURN — YOU ARE X");
    }
  }, difficulty === "hard" ? 250 : 400);
}

function findBestMove(b) {
  const available = b.map((v, i) => v ? -1 : i).filter(i => i >= 0);
  if (!available.length) return -1;

  // Hard: minimax. Medium: win/block, otherwise center/corners.
  if (difficulty === "hard") {
    let best = -Infinity;
    let choice = available[0];

    for (const index of available) {
      b[index] = "O";
      const value = minimax(b, 0, false);
      b[index] = "";
      if (value > best) {
        best = value;
        choice = index;
      }
    }
    return choice;
  }

  for (const mark of ["O", "X"]) {
    for (const index of available) {
      b[index] = mark;
      const wins = checkWinner(b) === mark;
      b[index] = "";
      if (wins) return index;
    }
  }

  if (b[4] === "") return 4;
  const corners = [0, 2, 6, 8].filter(i => !b[i]);
  if (corners.length) return corners[Math.floor(Math.random() * corners.length)];
  return available[Math.floor(Math.random() * available.length)];
}

function minimax(b, depth, maximizing) {
  const winner = checkWinner(b);
  if (winner === "O") return 10 - depth;
  if (winner === "X") return depth - 10;
  if (winner === "DRAW") return 0;

  if (maximizing) {
    let best = -Infinity;
    for (let i = 0; i < 9; i++) {
      if (b[i]) continue;
      b[i] = "O";
      best = Math.max(best, minimax(b, depth + 1, false));
      b[i] = "";
    }
    return best;
  }

  let best = Infinity;
  for (let i = 0; i < 9; i++) {
    if (b[i]) continue;
    b[i] = "X";
    best = Math.min(best, minimax(b, depth + 1, true));
    b[i] = "";
  }
  return best;
}

function endDuel(winner) {
  if (winner === "X") {
    score = 100;
    updateScore();
    finishGame(true, "You defeated the AI. Excellent strategy!");
  } else if (winner === "DRAW") {
    score = 40;
    updateScore();
    finishGame(true, "A draw! The AI couldn't beat you this time.");
  } else {
    finishGame(false, "The AI won this match. Study the board and challenge it again.");
  }
}
/* ---------- 6. SURVIVAL PROTOCOL ---------- */

function initSurvival() {
  const area = $("gameArea");

  area.innerHTML = `
    <div class="survival-world">
      <div class="survival-player" id="survivalPlayer">🚀</div>
    </div>`;

  const world = area.querySelector(".survival-world");
  const player = $("survivalPlayer");
  playerColumn = 1;

  function positionShip() {
    const width = area.clientWidth;
    player.style.left = Math.max(
      0, Math.min(width - 46, playerColumn * (width - 46) / 2)
    ) + "px";
  }

  function moveShip(dir) {
    if (!running || ended) return;
    playerColumn = Math.max(0, Math.min(2, playerColumn + dir));
    positionShip();
  }

  $("gameControls").innerHTML = `
    <button class="runner-btn" id="shipLeft">◀</button>
    <button class="runner-btn" id="shipRight">▶</button>`;

  $("shipLeft").onclick = () => moveShip(-1);
  $("shipRight").onclick = () => moveShip(1);
  positionShip();

  let frame = 0;
  const spawnEvery = difficulty === "hard" ? 5 :
    difficulty === "medium" ? 8 : 11;

  addTimer(() => {
    if (!running || ended) return;
    frame++;

    if (frame % spawnEvery === 0) {
      const hazard = document.createElement("div");
      hazard.className = "survival-hazard";
      hazard.textContent = Math.random() < .5 ? "☄️" : "✦";
      hazard.dataset.x = String(Math.random() * Math.max(1, area.clientWidth - 35));
      hazard.dataset.y = "-35";
      hazard.style.left = hazard.dataset.x + "px";
      world.appendChild(hazard);
      hazards.push(hazard);
    }

    hazards = hazards.filter(hazard => {
      if (!hazard.isConnected) return false;

      const y = Number(hazard.dataset.y) +
        (difficulty === "hard" ? 9 : difficulty === "medium" ? 6 : 4);
      hazard.dataset.y = y;
      hazard.style.top = y + "px";

      const hazardX = parseFloat(hazard.dataset.x);
      const shipX = parseFloat(player.style.left || "0");

      if (y > area.clientHeight - 75 && y < area.clientHeight - 10 &&
          Math.abs(hazardX - shipX) < 38) {
        finishGame(false, "Your ship was hit. Try changing lanes earlier next time.");
      }

      if (y > area.clientHeight) {
        hazard.remove();
        addScore(2);
        return false;
      }

      return true;
    });
  }, 70, true);

  addTimer(() => {
    if (!running || ended) return;
    seconds--;
    updateStat(seconds);
    addScore(1);

    if (seconds <= 0) {
      addScore(50);
      finishGame(true, "You survived the entire protocol! Bonus points awarded.");
    }
  }, 1000, true);
}

/* ---------- 7. DAILY QUEST ---------- */

function initDaily() {
  const area = $("gameArea");
  const missions = [
    { icon: "✨", title: "ENERGY COLLECTOR", desc: "Collect the required number of energy orbs." },
    { icon: "💠", title: "CRYSTAL HUNTER", desc: "Find and tap every glowing crystal." },
    { icon: "🌟", title: "STAR SEEKER", desc: "Gather stars to finish your mission." }
  ];

  const dayNumber = Math.floor(Date.now() / 86400000);
  const mission = missions[dayNumber % missions.length];

  area.innerHTML = `
    <div class="quest-card">
      <div class="quest-emoji">${mission.icon}</div>
      <p class="eyebrow">TODAY'S SPECIAL</p>
      <h3>${mission.title}</h3>
      <p>${mission.desc}</p>
      <div class="quest-progress" id="questProgress">0 / ${questGoal} COLLECTED</div>
      <div id="questTargetArea" style="position:relative;height:120px;margin-top:12px"></div>
    </div>`;

  const targetArea = $("questTargetArea");

  function spawnQuestTarget() {
    if (!running || ended) return;
    targetArea.innerHTML = "";

    const target = document.createElement("button");
    target.className = "target";
    target.textContent = mission.icon;
    target.style.width = "54px";
    target.style.height = "54px";
    target.style.left = (Math.random() * Math.max(0, targetArea.clientWidth - 60)) + "px";
    target.style.top = (Math.random() * 55) + "px";

    target.onclick = () => {
      if (!running || ended) return;

      questCount++;
      addScore(10);
      $("questProgress").textContent = `${questCount} / ${questGoal} COLLECTED`;
      setMessage("ORB COLLECTED!");

      if (questCount >= questGoal) {
        addScore(50);
        finishGame(true, "Quest complete! You collected every required orb.");
      } else {
        spawnQuestTarget();
      }
    };

    targetArea.appendChild(target);
  }

  spawnQuestTarget();

  addTimer(() => {
    if (!running || ended) return;
    seconds--;
    updateStat(seconds);

    if (seconds <= 0) {
      finishGame(questCount >= questGoal,
        "You collected " + questCount + " of " + questGoal + " orbs. Try again whenever you're ready.");
    }
  }, 1000, true);
}
/* ---------- KEYBOARD & MOBILE INPUT ---------- */

document.addEventListener("keydown", event => {
  if (!running || ended || paused) {
    if (event.key === "Escape" && !ended) togglePause();
    return;
  }

  if (["ArrowUp", "ArrowDown", "ArrowLeft", "ArrowRight", " "].includes(event.key)) {
    event.preventDefault();
  }

  if (currentGame === "runner") {
    if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") {
      $("leftLane")?.click();
    }
    if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") {
      $("rightLane")?.click();
    }
  }

  if (currentGame === "survival") {
    if (event.key === "ArrowLeft" || event.key.toLowerCase() === "a") {
      $("shipLeft")?.click();
    }
    if (event.key === "ArrowRight" || event.key.toLowerCase() === "d") {
      $("shipRight")?.click();
    }
  }

  if (currentGame === "nexus" && nexusKeyMove) {
    const keys = {
      ArrowLeft: "left", ArrowRight: "right",
      ArrowUp: "up", ArrowDown: "down",
      a: "left", d: "right", w: "up", s: "down"
    };

    const direction = keys[event.key] || keys[event.key.toLowerCase()];
    if (direction) nexusKeyMove(direction);
  }
});

document.addEventListener("visibilitychange", () => {
  if (document.hidden && running && !ended) {
    togglePause();
  }
});

/* ---------- INITIALIZE ---------- */

updateProfileUI();
showScreen("homeScreen");
